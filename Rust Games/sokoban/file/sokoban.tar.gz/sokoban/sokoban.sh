#!/bin/bash
./sokoban
